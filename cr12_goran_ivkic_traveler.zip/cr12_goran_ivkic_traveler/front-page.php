   <?php wp_head(); ?>
  
			<figure>
    				<div id="para" class="parallax_section1 parallax_image">
    				</div>
				<figcaption><h2><a id="enterSite" href="blog">ENTER SITE</h2></a></figcaption>
				<a><img class="img-fluid" style="background-size: cover;" src="<?php echo get_template_directory_uri(); ?>/img/front.jpg" alt="image"></a>
					<div id="para2" class="parallax_section1 parallax_image">
    				</div>	
			</figure>

  