
   
<div class="container-fluid">
    <?php get_header(); ?>

    <div class="parallax_section2 parallax_image">
    </div>
   
    <div class="parallax_section1 parallax_image">
    </div>

       <div class="parallax_section2 parallax_image">
                <div class="row">
                    <div class="card border-dark">
                        <div class="card-body">
  
                            <?php if(have_posts()) : ?> <!--  If there are posts available  -->

                            <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop-->
                                
                            <?php if(has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail(array(180)); ?> <!--Größe des thumbnails-->
                            <?php endif; ?><hr><!-- </img> -->

                            <h1 class="card-text"><?php the_title(); ?></h1>    <!--retrieves blog title-->

                            <p id="dateAuthor" class="card-text"><?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->

                            <p id="dateAuthor" class="card-text"><?php the_author(); ?></p><!--retrieves author of blog entry-->
       
                            <p class="card-text"><?php the_content(); ?></p><!--retrieves content-->
                            <p class="card-text"><?php comments_template(); ?></p>
                            <?php endwhile; ?><!--end the while loop-->

                            <?php else :?> <!-- if no posts are found then: -->

                            <p>No posts found</p> 

                            <?php endif; ?> <!-- end if -->
                        </div><!--END CARD BODY-->
                    </div><!--END CARD-->
                </div><!--END ROW-->
                
    </div><!--END PARALLAX 2-->

    <div class="parallax_section1 parallax_image">
    </div><!--END PARALLAX 1-->

    <div class="parallax_section2 parallax_image">
    </div>
</div>

 <?php get_footer(); ?>
